/*

33333
32223
32123
32223
33333

*/

#include<stdio.h>

int main(){
    int n;
    printf("Enter the number : ");
    scanf("%d",&n);
}